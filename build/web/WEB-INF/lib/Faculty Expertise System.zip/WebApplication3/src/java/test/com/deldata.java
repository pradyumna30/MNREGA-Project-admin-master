/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ruchir
 */
@WebServlet(name = "deldata", urlPatterns = {"/deldata"})
public class deldata extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws Exception{
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String id = request.getParameter("txtid");
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet deldata</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet deldata at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
            Connection con = null;
            ResultSet rst = null;
            Statement stmt = null;
           
        out.println("<link href='default.css' rel='stylesheet' type='text/css'>");
        String url = "jdbc:mysql://localhost:3306/faculty?user=root&password=ruchir";
        String dbName = "ruchir";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root"; 
        String password = "ruchir";
       // out.println("Cookie ");
        
           
           
        Class.forName(driver).newInstance();
       // out.println("In it");
        con = DriverManager.getConnection(url);
        
        stmt = con.createStatement();
        String s1="delete from ftable where fid='"+id+"'";
        stmt.executeUpdate(s1);
        String s2 = "delete from subtable where fid='"+id+"'";
        stmt.executeUpdate(s2);
        String s3 ="delete from exptable where fid='"+id+"'";
        stmt.executeUpdate(s3);
        
        out.println("<body bgcolor=Silver>");
                out.println("<br><br>");
                out.println("<center>");
                out.println("<h2>Data Deleted</h2>");
                out.println("<a href = Menu.jsp><h2>Go Back</h2>");
                out.println("</center>");
       out.println("<center>");
  out.println("Developed By : IET INCUBATION CENTER");
        }catch(Exception e){out.println("Exception in delete : "+e.getMessage());} finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(deldata.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(deldata.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
