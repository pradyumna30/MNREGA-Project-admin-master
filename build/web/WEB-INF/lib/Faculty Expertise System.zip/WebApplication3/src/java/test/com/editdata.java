/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ruchir
 */
@WebServlet(name = "editdata", urlPatterns = {"/editdata"})
public class editdata extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String name = request.getParameter("txtname");
        String stream = request.getParameter("txtstream");
        String phne = request.getParameter("txtphne");
        String email = request.getParameter("txtemail");
        String tyoe = request.getParameter("txtyoe");
        String  dept= request.getParameter("txtdept");
        String expt = request.getParameter("txtexpt");
        String sub = request.getParameter("txtsub");
        String respro = request.getParameter("txtrespro");
        String state = request.getParameter("state");
        String id = request.getParameter("txtid");
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet editdata</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet editdata at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
            
            Connection con = null;
            ResultSet rst = null;
            Statement stmt = null;
           
        out.println("<link href='default.css' rel='stylesheet' type='text/css'>");
        String url = "jdbc:mysql://localhost:3306/faculty?user=root&password=ruchir";
        String dbName = "ruchir";
        String driver = "com.mysql.jdbc.Driver";
        String userName = "root"; 
        String password = "ruchir";
       // out.println("Cookie ");
         float yoe = Float.parseFloat(tyoe);
         //  int phne =Integer.parseInt(tphne);
           
           
        Class.forName(driver).newInstance();
       // out.println("In it");
        con = DriverManager.getConnection(url);
        
        stmt = con.createStatement();
       String s1="delete * from ftable where fid=`"+id+"`";
        stmt.executeQuery(s1);
        String s2 = "delete * from subtable where fid=`"+id+"`";
        stmt.executeQuery(s2);
        String s3 ="delete * from exptable where fid=`"+id+"`";
        stmt.executeQuery(s3);
        
          StringTokenizer st = new StringTokenizer(sub,",");
  while(st.hasMoreTokens())
  {
      String command = "Insert into subtable(`Fid`,`sub`)"+"values(?,?)";
     PreparedStatement pstmt = con.prepareStatement(command);
 
     // out.println("Command for insertion in SUBtable initialized HERE");
            
            pstmt.setString(1,id);
            pstmt.setString(2,st.nextToken());
            int i = pstmt.executeUpdate();
  }
  
  //String command = "Insert into faculty('id','name','stream','dept','expt','sub'')"+"values(?,?,?,?,?,?,?)";
  String command = "Insert into ftable(`Fid`,`name`,`yoe`,`dept`,`phne`,`email`,`respro`,`state`,`stream`)"+"values(?,?,?,?,?,?,?,?,?)";
  PreparedStatement pstmt = con.prepareStatement(command);
 // out.println("Command initialized HERE");
            
            pstmt.setString(1,id);
            pstmt.setString(2,name);
            pstmt.setFloat(3,yoe);
            pstmt.setString(4,dept);
            pstmt.setString(5,phne);
            pstmt.setString(6,email);
            pstmt.setString(7,respro);
            pstmt.setString(8,state);
            pstmt.setString(9,stream);
            
           // out.println("Command Executed HERE");
            int i = pstmt.executeUpdate();
            out.println("i="+i);
            if(i==1)
            {
                 
                out.println("<body bgcolor=Silver>");
                out.println("<br><br>");
                out.println("<center>");
                out.println("<h2>Data Inserted</h2>");
                out.println("<a href = Menu.jsp><h2>Go Back</h2>");
                out.println("</center>");
            }
            else
            {
                out.println("Attempt Failed Try Again");
                
                out.println("<a href = Menu.jsp><h2>Go Back</h2>");
            }
   out.println("<center>");
  out.println("Developed By : IET INCUBATION CENTER");
        }catch(Exception e)
        {out.println("Exception : "+e.getMessage());}finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(editdata.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(editdata.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
