/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ruchir
 */
@WebServlet(name = "sdept", urlPatterns = {"/sdept"})
public class sdept extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String sel = request.getParameter("combo1");
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet sdept</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet sdept at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */Connection con = null;
            ResultSet rst = null;
            Statement stmt = null;
            Statement st=null;
            Statement stt=null;
           
        out.println("<link href='default.css' rel='stylesheet' type='text/css'>");
        out.println("<center>");
        out.println("<h1>SEARCH RESULT</h1>");
     
       
        String url = "jdbc:mysql://localhost:3306/faculty?user=root&password=ruchir";
        String dbName = "ruchir";
        String driver = "com.mysql.jdbc.Driver";
        Class.forName(driver).newInstance();
       // out.println("In it");
        con = DriverManager.getConnection(url);
        stmt=con.createStatement();
        st= con.createStatement() ;
   stt= con.createStatement() ;
   
        String sql = "Select * from ftable where dept ='"+sel+"'";
        rst=stmt.executeQuery(sql);
        
                    
                out.println("<TABLE BORDER='1'>");
                out.println("<TR>");
                
                out.println("<TH>Name</TH>");
                out.println("<TH>Department</TH>");
                out.println("<TH>Years Of Exp</TH>");
                out.println("<TH>Phone Number</TH>");
                out.println("<TH>Email</TH>");
                out.println("<TH>Respro</TH>");
                out.println("<TH>ID</TH>");
                out.println("<TH>State</TH>");
                out.println("<TH>Expertise</th>");
                out.println("<TH>Subjects Taught</th>");
                out.println("<TH>Stream</th>");
                out.println("</TR>");
             while(rst.next())
             { 
                String exp="",sub="";
                 ResultSet rst2 = st.executeQuery("select * from exptable where fid='"+rst.getString(7)+"'");
            while(rst2.next())
            {
                exp=exp+rst2.getString(2)+",";
            }
            
            ResultSet rst1 = stt.executeQuery("select * from subtable where fid='"+rst.getString(7)+"'");
            while(rst1.next())
            {
                sub=sub+rst1.getString(2)+",";
            }
                out.println("<TR>");
                out.println("<TD>"+  rst.getString(1)+ "</td>");
                out.println("<TD>"+  rst.getString(2)+ "</TD>");
                out.println("<TD>"+  rst.getString(3) + "</TD>");
                out.println("<TD>"+  rst.getString(4) + "</TD>");
                out.println("<TD>"+  rst.getString(5) + "</TD>");
                out.println("<TD>"+  rst.getString(6) + "</TD>");
                out.println("<TD>"+  rst.getString(7) + "</TD>");
                out.println("<TD>"+  rst.getString(8)+ "</TD>");
                out.println("<TD>"+  exp +"</TD>");
                out.println("<TD>"+  sub+ "</TD>");
                out.println("<TD>"+  rst.getString(9)+ "</TD>");
                out.println("</TR>");
             }
                  
                 
                   
                        out.println("</select></td><br><br>");
                        

            out.println("<a href='state.jsp'>Go Back</a><br><br>");
            out.println("Developed By : IET INCUBATION CENTER<br><br>");
            out.println("</center>");
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(sdept.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(sdept.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
