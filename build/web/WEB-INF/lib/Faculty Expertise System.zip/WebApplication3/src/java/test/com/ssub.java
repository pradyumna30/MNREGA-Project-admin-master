/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ruchir
 */
@WebServlet(name = "ssub", urlPatterns = {"/ssub"})
public class ssub extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws Exception{
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String sel = request.getParameter("txtname");
        String type = request.getParameter("radios");
        String id;
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ssub</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ssub at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
             */
            Connection con = null;
            ResultSet rst = null;
            Statement stmt = null;
            Statement st=null;
            Statement stt=null;
            Statement st3 = null;
           
        out.println("<link href='default.css' rel='stylesheet' type='text/css'>");
        out.println("<center>");
        out.println("<h1>SEARCH RESULT</h1>");
     
       
        String url = "jdbc:mysql://localhost:3306/faculty?user=root&password=ruchir";
        String dbName = "ruchir";
        String driver = "com.mysql.jdbc.Driver";
        Class.forName(driver).newInstance();
        // out.println("In it");
        con = DriverManager.getConnection(url);
        stmt=con.createStatement();
        st= con.createStatement();
        stt= con.createStatement();
        st3 = con.createStatement();
        
        out.println("<TABLE BORDER='1'>");
                out.println("<TR>");
                
                out.println("<TH>Name</TH>");
                out.println("<TH>Department</TH>");
                out.println("<TH>Years Of Exp</TH>");
                out.println("<TH>Phone Number</TH>");
                out.println("<TH>Email</TH>");
                out.println("<TH>Respro</TH>");
                out.println("<TH>ID</TH>");
                out.println("<TH>State</TH>");
                out.println("<TH>Expertise</th>");
                out.println("<TH>Subjects Taught</th>");
                out.println("<TH>Stream</th>");
                out.println("</TR>");
                //String exp="",subj="";
        if(type.equals("radio1"))
       {
           String sql = "Select * from subtable where sub ='"+sel+"'";
           rst=stmt.executeQuery(sql);
           out.println("radio 1");
       // out.println("radio 1");
           while(rst.next())
             { 
                String exp="",subj="";
                 ResultSet rst3 = st3.executeQuery("select * from subtable where fid='"+rst.getString(1)+"'");
                while(rst3.next())
                {
                      subj=subj+rst.getString(2)+",";
                }
                
                ResultSet rst2 = st.executeQuery("select * from ftable where fid='"+rst.getString(1)+"'");
                
                ResultSet rst1 = stt.executeQuery("select * from exptable where fid='"+rst.getString(1)+"'");
                while(rst1.next())
                {
                    //exp=exp+rst2.getString(2)+",";
                    exp=exp+rst1.getString(2)+",";
                 }
                //out.println(subj+":"+exp);
                while(rst2.next())
                {
                out.println("<TR>");
                out.println("<TD>"+  rst2.getString(1)+ "</td>");
                out.println("<TD>"+  rst2.getString(2)+ "</TD>");
                out.println("<TD>"+  rst2.getString(3) + "</TD>");
                out.println("<TD>"+  rst2.getString(4) + "</TD>");
                out.println("<TD>"+  rst2.getString(5) + "</TD>");
                out.println("<TD>"+  rst2.getString(6) + "</TD>");
                out.println("<TD>"+  rst2.getString(7) + "</TD>");
                out.println("<TD>"+  rst2.getString(8)+ "</TD>");
                out.println("<TD>"+  exp +"</TD>");
                out.println("<TD>"+  subj+ "</TD>");
                out.println("<TD>"+  rst.getString(9)+ "</TD>");
                out.println("</TR>");
                }
            }    
       }
        if(type.equals("radio2"))
       {
           String sql = "Select * from exptable where exp ='"+sel+"'";
           rst=stmt.executeQuery(sql);
          
       // out.println("radio 2");
           while(rst.next())
             { 
                String exp="",subj="";
                 ResultSet rst3 = st3.executeQuery("select * from subtable where fid='"+rst.getString(1)+"'");
                while(rst3.next())
                {
                      subj=subj+rst.getString(2)+",";
                }
                
                ResultSet rst2 = st.executeQuery("select * from ftable where fid='"+rst.getString(1)+"'");
                
                ResultSet rst1 = stt.executeQuery("select * from exptable where fid='"+rst.getString(1)+"'");
                while(rst1.next())
                {
                    //exp=exp+rst2.getString(2)+",";
                    exp=exp+rst1.getString(2)+",";
                 }
               // out.println(subj+":"+exp);
                while(rst2.next())
                {
                out.println("<TR>");
                out.println("<TD>"+  rst2.getString(1)+ "</td>");
                out.println("<TD>"+  rst2.getString(2)+ "</TD>");
                out.println("<TD>"+  rst2.getString(3) + "</TD>");
                out.println("<TD>"+  rst2.getString(4) + "</TD>");
                out.println("<TD>"+  rst2.getString(5) + "</TD>");
                out.println("<TD>"+  rst2.getString(6) + "</TD>");
                out.println("<TD>"+  rst2.getString(7) + "</TD>");
                out.println("<TD>"+  rst2.getString(8)+ "</TD>");
                out.println("<TD>"+  exp +"</TD>");
                out.println("<TD>"+  subj+ "</TD>");
                out.println("</TR>");
                
                }
            }    
       }
         out.println("<a href='state.jsp'>Go Back</a><br><br>"); 
        out.println("<center>");
  out.println("Developed By : IET INCUBATION CENTER");
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(ssub.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Exception ex) {
            Logger.getLogger(ssub.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
